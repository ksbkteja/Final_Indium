import React from "react";

class Countries extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      firstname: "",
      lastname: "",
    };
  }

  handleClick = (node) => {
    if (node) {
      this.setState(
        {
          firstname: node.user.name.first,
          lastname: node.user.name.last,
        },
        () => {
          alert(`Written by -${this.state.firstname} ${this.state.lastname}`);
        }
      );
    }
  };

  componentDidMount() {
    let url = "https://cat-fact.herokuapp.com/facts";
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    }).then((result) => {
      result.json().then((resp) => {
        this.setState({ data: resp.all });
      });
    });
  }

  render() {
    const data = this.state.data;
    return (
      <React.Fragment>
        <h1>Facts-Indium</h1>
        {data.map((eachdata) => (
          <React.Fragment className="main">
            <p className="box" onClick={() => this.handleClick(eachdata)}>
              "Fact"-{eachdata.text}
            </p>
          </React.Fragment>
        ))}
      </React.Fragment>
    );
  }
}

export default Countries;
