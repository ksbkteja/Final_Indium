import React from "react";
import "./App.css";
import Countries from "./Countries";

function App() {
  return (
    <div className="App">
      <Countries />
    </div>
  );
}

export default App;
